//
//  ViewController.m
//  SDauthCode
//
//  Created by songjc on 16/9/7.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import "ViewController.h"
#import "SDauthCode.h"
@interface ViewController ()

@property(nonatomic,strong)SDauthCode *codeView;


@property (strong, nonatomic) IBOutlet UITextField *textField;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.codeView = [[SDauthCode alloc]initWithFrame:CGRectMake(100, 100, 200, 40)];
    
    [self.view addSubview:self.codeView];

}



- (IBAction)reloadAuthCodeView:(id)sender {
    
    
    [self.codeView reloadAuthCodeView];

}


- (IBAction)finishInput:(id)sender {
    
    
    if ([self.codeView.authCodeString isEqualToString:self.textField.text]) {
        
        //这里面写验证正确之后的动作.
        [self.codeView reloadAuthCodeView];

        tipWithMessage(@"输入验证码正确");
    }else{
        
        //这里面写验证失败之后的动作.

        [self.codeView reloadAuthCodeView];

        tipWithMessage(@"输入验证码错误");
    }
    
    
}

NS_INLINE void tipWithMessage(NSString *message){
    
    dispatch_async(dispatch_get_main_queue(), ^{
        
        UIAlertView *alerView = [[UIAlertView alloc] initWithTitle:@"提示" message:message delegate:nil cancelButtonTitle:nil otherButtonTitles:nil, nil];
        
        [alerView show];
        
        [alerView performSelector:@selector(dismissWithClickedButtonIndex:animated:) withObject:@[@0, @1] afterDelay:0.9];
        
    });
    
}

@end
